package com.pixo.controller;

import java.io.IOException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.commons.CommonsMultipartFile;
import com.pixo.bean.MyMedia;
import com.pixo.bean.ProfilePicture;
import com.pixo.bean.User;
import com.pixo.dao.UserDAO;
import com.pixo.service.UserService;

@RestController
@RequestMapping("/user")
public class UserController {
	
	@Autowired
	private UserService userService;
	
	@Autowired
	private UserDAO userDAO;
	
	@PostMapping("/registerUser")
	public ResponseEntity<Void> registerUser(@RequestBody User user){
		ResponseEntity<Void> response=null;
		boolean result=userService.registerUser(user);
		if(result)
		{	
		response=new ResponseEntity<Void>(HttpStatus.OK);
		}	
		else
		{
			
		response=new ResponseEntity<Void>(HttpStatus.NOT_ACCEPTABLE);
	}
		return response;
	}
	
	@GetMapping("/LoginUser")
	public ResponseEntity<Void>  UserAuthentication(@RequestBody User user,HttpServletRequest request){	
		ResponseEntity<Void> response=null;
	  	String eMail=user.getEmail();
	  	String password=user.getPassword();
    	boolean result=userService.authenticate(eMail, password);
    	HttpSession session=request.getSession();
    	session.setAttribute("EmailId", eMail);
    	
    	if(result==true){
    		
    		session.setAttribute("UserEmail", eMail);
    		response=new ResponseEntity<Void>(HttpStatus.OK);
    		
    	}
    	else{	
    		
    		response=new ResponseEntity<Void>(HttpStatus.CONFLICT);
    	}   	
    	return response;
    }
	
	 @PostMapping("/uploadPicture")
	 public ResponseEntity<Void> handleFileUpload(HttpServletRequest request,@RequestParam CommonsMultipartFile[] profilePicture) throws Exception {
		 ResponseEntity<Void> response=null;
	        if (profilePicture != null && profilePicture.length > 0) {
	            for (CommonsMultipartFile aFile : profilePicture)
	            {      
	                int userId=(int)request.getSession().getAttribute("UserId"); 
	                ProfilePicture pic = new ProfilePicture();
	                pic.setFileName(aFile.getOriginalFilename());
	                pic.setData(aFile.getBytes());
	                pic.setUserId(userId);
	                boolean result=userDAO.uploadProfilePicture(pic);
	                if(result)
	                {
	                	response=new ResponseEntity<Void>(HttpStatus.ACCEPTED);
	                }
	            }
	        }	  
	        return response;
	    }
	 @PostMapping("/showImage")
	 public ResponseEntity<Void> showImage(HttpServletRequest request, HttpServletResponse response){	
		 ResponseEntity<Void> responseEntity=null;
	    	HttpSession session=request.getSession();
	    	int userId=(int)request.getSession().getAttribute("UserId"); 
	    	ProfilePicture picture=userDAO.showImage(userId);
	    	
	    	response.setContentType("image/jpeg, image/jpg, image/png, image/gif");
	        try {
				response.getOutputStream().write(picture.getData());
				response.getOutputStream().close();
				responseEntity=new ResponseEntity<Void>(HttpStatus.ACCEPTED);
			} catch (IOException e) {			
				e.printStackTrace();
			}	        	   
	    	return responseEntity;
	    }
	 
	 @PostMapping("/uploadMedia")
	 public ResponseEntity<Void> uploadMedia(HttpServletRequest request,@RequestParam CommonsMultipartFile[] media,@RequestParam("title") String title,
	    		@RequestParam("description") String description,@RequestParam("tags") String tags) throws Exception {
		 ResponseEntity<Void> responseEntity=null;
	        if (media != null && media.length > 0) {
	            for (CommonsMultipartFile aFile : media)
	            {      
	                int userId=(int)request.getSession().getAttribute("UserId"); 
	                MyMedia myMedia=new MyMedia();
	                myMedia.setMedia(aFile.getBytes());
	                myMedia.setTitle(title);
	                myMedia.setDescription(description);
	                myMedia.setTag(tags);
	                myMedia.setUserId(userId);
	                boolean result=userDAO.uploadMedia(myMedia);
	                if(result)
	                {
	                	responseEntity=new ResponseEntity<Void>(HttpStatus.OK);
	                }
	                else
	                {
	                	responseEntity=new ResponseEntity<Void>(HttpStatus.NOT_FOUND);
	                }
	            }
	        }	  
	        return responseEntity;
	    }
	 	@PostMapping("/uploadMultipleMedia")
	 	public ResponseEntity<Void> uploadMultipleMedia(HttpServletRequest request,@RequestParam CommonsMultipartFile[] media,@RequestParam("title") String title,
	    		@RequestParam("description") String description,@RequestParam("tags") String tags) throws Exception {
	 		 ResponseEntity<Void> responseEntity=null;
	        if (media != null && media.length > 0) {
	            for (CommonsMultipartFile aFile : media)
	            {      
	                int userId=(int)request.getSession().getAttribute("UserId"); 
	                MyMedia myMedia=new MyMedia();
	                myMedia.setMedia(aFile.getBytes());
	                myMedia.setTitle(title);
	                myMedia.setDescription(description);
	                myMedia.setTag(tags);
	                myMedia.setUserId(userId);
	                boolean result=userDAO.uploadMedia(myMedia);
	                if(result)
	                {
	                	responseEntity=new ResponseEntity<Void>(HttpStatus.OK);
	                }
	                else
	                {
	                	responseEntity=new ResponseEntity<Void>(HttpStatus.CONFLICT);
	                }
	            }
	        }	  
	        return responseEntity;
	    }
	 	@GetMapping("/welcome")
	 	public ResponseEntity<Void> WelcomePage(HttpServletRequest request){	
			
			      	      
			 ResponseEntity<Void> responseEntity=null;
	    	HttpSession session=request.getSession();
	    	String emailId=(String)request.getSession().getAttribute("EmailId"); 
	    	User user=userService.getUser(emailId);
	    	String name=user.getName();
	    	int id=user.getId();
	    	session.setAttribute("UserId", id);
	    	responseEntity=new ResponseEntity<Void>(HttpStatus.OK);
	    	return responseEntity;
	    }
	 
	 @PostMapping("/accountUpdate")
	 public ResponseEntity<Void> accountUpdatePage(HttpServletRequest request){
		 
		  	      
			 ResponseEntity<Void> responseEntity=null;
	    	HttpSession session=request.getSession();
	    	String emailId=(String)request.getSession().getAttribute("EmailId"); 
	    	User user=userService.getUser(emailId);
	    	String name=user.getName();
	    	int id=user.getId();
	    	session.setAttribute("UserId", id);
	    	responseEntity=new ResponseEntity<Void>(HttpStatus.OK);
			return responseEntity;
		}
	 
	 @PostMapping("/news")
	 public ResponseEntity<Void> News(HttpServletRequest request){
		      	      
		 ResponseEntity<Void> responseEntity=null;
	    	HttpSession session=request.getSession();
	    	String emailId=(String)request.getSession().getAttribute("EmailId"); 
	    	
	    	User user=userService.getUser(emailId);
	    	String name=user.getName();
	    	int id=user.getId();
	    	session.setAttribute("UserId", id);
	    	responseEntity=new ResponseEntity<Void>(HttpStatus.OK);
			
			return responseEntity;
		}
	 @GetMapping("/singlemedia")
	 public ResponseEntity<Void> UploadSinglePage(HttpServletRequest request){
		      	      
		 ResponseEntity<Void> responseEntity=null;
	    	HttpSession session=request.getSession();
	    	String emailId=(String)request.getSession().getAttribute("EmailId"); 
	    	User user=userService.getUser(emailId);
	    	String name=user.getName();
	    	int id=user.getId();
	    	session.setAttribute("UserId", id);
	    	responseEntity=new ResponseEntity<Void>(HttpStatus.OK);
			return responseEntity;
		}
	 @GetMapping("/multiplemedia")
	 public ResponseEntity<Void> UploadMultiplePage(HttpServletRequest request){
		      	      
		 ResponseEntity<Void> responseEntity=null;
	    	HttpSession session=request.getSession();
	    	String emailId=(String)request.getSession().getAttribute("EmailId"); 
	    	User user=userService.getUser(emailId);
	    	String name=user.getName();
	    	int id=user.getId();
	    	session.setAttribute("UserId", id);
	    	responseEntity=new ResponseEntity<Void>(HttpStatus.OK);
			return responseEntity;
		}
	 @GetMapping("/home")
	 public ResponseEntity<Void> Home(HttpServletRequest request){
		  	      
		 ResponseEntity<Void> responseEntity=null;
	    	HttpSession session=request.getSession();
	    	String emailId=(String)request.getSession().getAttribute("EmailId"); 
	    	User user=userService.getUser(emailId);
	    	String name=user.getName();
	    	int id=user.getId();
	    	session.setAttribute("UserId", id);
	    	responseEntity=new ResponseEntity<Void>(HttpStatus.OK);
			
			return responseEntity;
		}
	 
}
