import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-upload-single-media',
  templateUrl: './upload-single-media.component.html',
  styleUrls: ['./upload-single-media.component.css']
})
export class UploadSingleMediaComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
