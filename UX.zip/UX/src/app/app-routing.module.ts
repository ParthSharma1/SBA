import { FollowersComponent } from './followers/followers.component';
import { UploadSingleMediaComponent } from './upload-single-media/upload-single-media.component';
import { UploadMediaMultipleComponent } from './upload-media-multiple/upload-media-multiple.component';
import { BlockedAccountsComponent } from './blocked-accounts/blocked-accounts.component';
import { SearchComponent } from './search/search.component';
import { AccountDetailsComponent } from './account-details/account-details.component';
import { MyMediaPageComponent } from './my-media-page/my-media-page.component';
import { AppComponent } from './app.component';
import { RegisterComponent } from './register/register.component';

import { NgModule, Component } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { NewsFeedComponent } from './news-feed/news-feed.component';

const routes: Routes = [
    {path: "", redirectTo: "/app-root", pathMatch: "full"},
    {path:"app-root",component:AppComponent},
   
    {path : 'register',component :RegisterComponent},
    {path : 'my-media-page' ,component :MyMediaPageComponent},
    {path : 'account-details',component :AccountDetailsComponent},
    {path: 'news-feed',component :NewsFeedComponent},
    {path: 'search',component :SearchComponent},
    {path: 'blocked-accounts',component :BlockedAccountsComponent},
    {path: 'upload-media-multiple',component :UploadMediaMultipleComponent},
    {path: 'upload-single-media',component :UploadSingleMediaComponent},
    {path: 'followers',component :FollowersComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
export const routingcomponents= [RegisterComponent,
  MyMediaPageComponent,AccountDetailsComponent,NewsFeedComponent,
  SearchComponent,BlockedAccountsComponent,UploadMediaMultipleComponent
  ,UploadSingleMediaComponent,FollowersComponent
]; 


